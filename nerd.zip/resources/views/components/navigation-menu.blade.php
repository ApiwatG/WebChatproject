<nav>
    <ul>
        <li><a href="{{ route('dashboard') }}">Dashboard</a></li>
        <li><a href="{{ route('admin.dashboard') }}">Admin Dashboard</a></li>
        <li><a href="{{ route('profile.show') }}">Profile</a></li>
    </ul>
</nav>
